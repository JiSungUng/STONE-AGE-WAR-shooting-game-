import java.awt.Graphics;
import java.awt.Point;
import java.awt.Rectangle;

import javax.swing.ImageIcon;

public class Shape extends ImageIcon {
	ImageIcon img;
	int x, y;
	double xx;
	double yy;
	int width, height;
	double moveX, moveY;

	public Shape(ImageIcon shape, int x, int y, int width, int height) {
		super(shape.getImage());
		this.img = img;
		this.x = x;
		this.xx = (double) x;
		this.y = y;
		this.yy = (double) y;
		this.width = width;
		this.height = height;
	}

	// �浹
	public boolean collide(Rectangle rc) {
		return rc.intersects((double) x, (double) y, (double) width, (double) height);
	}

	// ���
	public Point center() {
		return new Point(x + width / 2, y + height / 2);

	}

	public void move() {
		this.x += moveX;
		this.y += moveY;
	}

	public void draw(Graphics g) {
		g.drawImage(this.getImage(), x, y, width, height, null);
	}

}
