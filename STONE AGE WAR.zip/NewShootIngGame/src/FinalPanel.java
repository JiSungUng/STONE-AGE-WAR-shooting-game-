import java.awt.Font;
import java.awt.Graphics;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class FinalPanel extends JPanel {

	GamePanel gamePanel = new GamePanel();

	ImageIcon finalImage = new ImageIcon("src/Images/background4.png");

	JLabel final_score;
	JButton exit = new JButton("�����ϱ�");
	JButton restart = new JButton("�ٽ��ϱ�");

	int Score1;

	public FinalPanel() {
		setLayout(null);
		setSize(1280, 720);
		setVisible(true);

		exit.setBounds(700, 540, 400, 80);
		exit.setBorderPainted(false);
		exit.setContentAreaFilled(false);
		exit.setFocusPainted(false);
		exit.setFont(new Font("����", Font.BOLD, 50));
		add(exit);

		restart.setBounds(100, 540, 400, 80);
		restart.setBorderPainted(false);
		restart.setContentAreaFilled(false);
		restart.setFocusPainted(false);
		restart.setFont(new Font("����", Font.BOLD, 50));
		add(restart);

		final_score = new JLabel("score" + Score1);
		final_score.setFont(new Font("����", Font.BOLD, 80));
		add(final_score);
	}

	public void paintComponent(Graphics g) {
		g.drawImage(finalImage.getImage(), 0, 0, null);
		final_score.setBounds(450, 100, 600, 400);
		final_score.setText("score: " + Score1);
		repaint();
	}
}
