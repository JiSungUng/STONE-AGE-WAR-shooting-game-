import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.ArrayList;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.Timer;

public class GamePanel extends JPanel {
	Character main_character;
	ImageIcon gameImage = new ImageIcon("src/Images/background3.png");
	ImageIcon character_IMG = new ImageIcon("src/Images/CHARACTER.png");
	ImageIcon dinosaur1_IMG = new ImageIcon("src/Images/dinosaur1.png");
	ImageIcon dinosaur2_IMG = new ImageIcon("src/Images/dinosaur2.png");
	ImageIcon dinosaur3_IMG = new ImageIcon("src/Images/dinosaur3.png");
	ImageIcon dinosaur4_IMG = new ImageIcon("src/Images/dinosaur4.png");
	ImageIcon dinosaur5_IMG = new ImageIcon("src/Images/dinosaur5.png");
	ImageIcon arrow_IMG = new ImageIcon("src/Images/arrow.png");
	ImageIcon fire_IMG = new ImageIcon("src/Images/fire.png");

	Timer screenTimer;
	int move_screen = 0;
	int time = 0;
	boolean lose;

	ArrayList<Character> character_attack = new ArrayList<>();
	ArrayList<Character> delete_attack = new ArrayList<>();

	ArrayList<Character> dinosaur1_attack = new ArrayList<Character>();
	ArrayList<Character> dinosaur2_attack = new ArrayList<Character>();
	ArrayList<Character> dinosaur1 = new ArrayList<Character>();
	ArrayList<Character> dinosaur2 = new ArrayList<Character>();
	ArrayList<Character> dinosaur3 = new ArrayList<Character>();
	ArrayList<Character> dinosaur4 = new ArrayList<Character>();
	ArrayList<Character> dinosaur5 = new ArrayList<Character>();

	JLabel score;
	int Score = 0;
	JLabel life;
	int Life = 3;

	// Panel�� ���� ����
	public GamePanel() {
		setLayout(null);
		setSize(1280, 720);

		score = new JLabel("score" + Score);
		score.setFont(new Font("����", Font.BOLD, 80));

		this.add(score);

		life = new JLabel("LIFE : " + life);
		life.setFont(new Font("����", Font.BOLD, 50));
		this.add(life);

		screenTimer = new Timer(10, new screenTime());
	}

	public void paintComponent(Graphics g) {
		int w = this.getWidth();
		int h = this.getHeight();

		g.drawImage(gameImage.getImage(), move_screen, 0, w, h, null);
		g.drawImage(gameImage.getImage(), move_screen + 1280, 0, w, h, null);

		main_character.draw(g);

		for (Character dino1 : dinosaur1) {
			dino1.draw(g);
		}
		for (Character dino2 : dinosaur2) {
			dino2.draw(g);
		}

		for (Character a : character_attack) {
			a.draw(g);

		}
		for (Character dino1 : dinosaur1_attack) {
			dino1.drawdA(g);
		}
		for (Character dino2 : dinosaur2_attack) {
			dino2.drawdA(g);
		}

		score.setBounds(30, -160, 500, 400);
		score.setText("score: " + Score);
		life.setBounds(30, 0, 300, 200);
		life.setText("Life : " + Life);

		repaint();
	}

	class screenTime implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			move_screen -= 2;
			if (move_screen < -1280)
				move_screen = 0;

		}

	}

}
