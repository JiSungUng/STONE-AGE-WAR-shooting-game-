import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JPanel;

public class FirstPanel extends JPanel {
	ImageIcon firstImage = new ImageIcon("src/images/background1.png");

	JButton startButton = new JButton("");
	JButton secondButton = new JButton("");

	public FirstPanel() {
		setLayout(null);
		setSize(1280, 720);
		setVisible(true);

		startButton.setBounds(810, 540, 400, 80);
		startButton.setBorderPainted(false);
		startButton.setContentAreaFilled(false);
		startButton.setFocusPainted(false);
		add(startButton);

		secondButton.setBounds(100, 540, 400, 80);
		secondButton.setBorderPainted(false);
		secondButton.setContentAreaFilled(false);
		secondButton.setFocusPainted(false);
		add(secondButton);
	}

	public void paintComponent(Graphics g) {
		g.drawImage(firstImage.getImage(), 0, 0, null);
	}
}
