import java.awt.Font;
import java.awt.Graphics;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JPanel;

public class SecondPanel extends JPanel {
	ImageIcon secondImage = new ImageIcon("src/Images/background2.png");
	JButton go_firstscreen = new JButton("�ڷΰ���");

	// Panel�� ���� ����
	public SecondPanel() {
		setLayout(null);
		setSize(1280, 720);
		setVisible(true);

		go_firstscreen.setBounds(100, 540, 400, 80);
		go_firstscreen.setBorderPainted(false);
		go_firstscreen.setContentAreaFilled(false);
		go_firstscreen.setFocusPainted(false);
		go_firstscreen.setFont(new Font("����", Font.BOLD, 50));
		add(go_firstscreen);

	}

	public void paintComponent(Graphics g) {	
		g.drawImage(secondImage.getImage(), 0, 0, null);
	}

}