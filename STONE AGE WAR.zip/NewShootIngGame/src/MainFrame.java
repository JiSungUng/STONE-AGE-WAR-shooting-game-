import java.awt.CardLayout;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.Timer;

public class MainFrame extends JFrame implements ActionListener, KeyListener {

	Timer screenTimer;
	Timer atTimer;
	Timer gameTimer;
	Timer dinoTimer;

	int move_screen = 0;
	int time = 0;
	int i = 0;	
	int a;
	int startX = 100;
	int startY = 300;
	boolean up, down, right, left;
	boolean lose;
	boolean startp = false;
	FirstPanel firstPanel = new FirstPanel();
	SecondPanel secondPanel = new SecondPanel();
	GamePanel gamePanel = new GamePanel();
	FinalPanel finalPanel = new FinalPanel();

	CardLayout card = new CardLayout();

	// Frame�� ���� ���� (set~~)
	public MainFrame() {
		setTitle("Stone Age War");
		setSize(1300, 720);
		setResizable(false);
		setLocationRelativeTo(null);	
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		getContentPane().setFocusable(true);
		getContentPane().requestFocus();
		getContentPane().addKeyListener(this);
		getContentPane().addKeyListener(new attackTime());
		getContentPane().addKeyListener(new character_move());
		getContentPane().setLayout(card);
		getContentPane().add("firstPanel", firstPanel);
		getContentPane().add("secondPanel", secondPanel);
		getContentPane().add("gamePanel", gamePanel);
		getContentPane().add("finalPanel", finalPanel);

		card.show(getContentPane(), "firstPanel");

		gamePanel.main_character = new Character(gamePanel.character_IMG, startX, startY, 100, 100);

		 atTimer = new Timer(600, new attackTime());
		 dinoTimer = new Timer(1000, new createDinosaur());
		 gameTimer = new Timer(1, new GameTimer());

		

		repaint();
		setVisible(true);
	}

	public void go() {
		firstPanel.startButton.addActionListener(this);
		firstPanel.secondButton.addActionListener(this);
		secondPanel.go_firstscreen.addActionListener(this);
		finalPanel.exit.addActionListener(this);
		finalPanel.restart.addActionListener(this);

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == firstPanel.startButton) { // ���ӽ���

			card.show(getContentPane(), "gamePanel");
			gamePanel.screenTimer.start();
			dinoTimer.start();
			gameTimer.start();
			atTimer.start();
		} else if (e.getSource() == firstPanel.secondButton) { // ���� ����

			card.show(getContentPane(), "secondPanel");

		} else if (e.getSource() == secondPanel.go_firstscreen) { // ���� â���� �ǵ��ư���

			card.show(getContentPane(), "firstPanel");

		} else if (e.getSource() == finalPanel.restart) { // ������ ��鿡�� ù ȭ������

			card.show(getContentPane(), "firstPanel");
			gamePanel.dinosaur1.removeAll(gamePanel.dinosaur1);
			gamePanel.dinosaur1_attack.removeAll(gamePanel.dinosaur1_attack);
			gamePanel.dinosaur2.removeAll(gamePanel.dinosaur2);
			gamePanel.dinosaur2_attack.removeAll(gamePanel.dinosaur2_attack);
			gamePanel.main_character.pX = startX;
			gamePanel.main_character.pY = startY;
			gamePanel.Score = 0;
			finalPanel.Score1 = 0;
			gamePanel.setFocusable(true);
			gamePanel.requestFocus();
			gamePanel.Life = 3;
		} else if (e.getSource() == finalPanel.exit) { // ���� ��ư
			System.exit(1);
		}

	}

	public static void main(String[] args) {
		MainFrame main = new MainFrame();
		main.go();
	}

	@Override
	public void keyTyped(KeyEvent e) {

	}

	class character_move implements KeyListener {

		@Override
		public void keyTyped(KeyEvent e) {

		}

		@Override
		public void keyPressed(KeyEvent e) {
			int key = e.getKeyCode();
			if (key == KeyEvent.VK_UP)
				up = true;

			if (key == KeyEvent.VK_DOWN)
				down = true;

			if (key == KeyEvent.VK_LEFT)
				left = true;

			if (key == KeyEvent.VK_RIGHT)
				right = true;

			gamePanel.setFocusable(true);

		}

		@Override
		public void keyReleased(KeyEvent e) {
			int key = e.getKeyCode();
			if (key == KeyEvent.VK_UP)
				up = false;

			if (key == KeyEvent.VK_DOWN)
				down = false;

			if (key == KeyEvent.VK_LEFT)
				left = false;

			if (key == KeyEvent.VK_RIGHT)
				right = false;

		}

	}

	class attackTime implements KeyListener, ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {

			for (Character b : gamePanel.dinosaur1)
				if (b.pX > 0) {
					if (time % 5 == 0 || time % 5 == 1) {
						DAtk();
					}
				}
		}

		@Override
		public void keyTyped(KeyEvent e) {

		}

		@Override
		public void keyPressed(KeyEvent e) {

			switch (e.getKeyCode()) {
			case KeyEvent.VK_SPACE:
				gamePanel.character_attack.add(new Character(gamePanel.arrow_IMG, gamePanel.main_character.pX + 30,
						gamePanel.main_character.pY, 60, 60));

				break;
			}

		}

		@Override
		public void keyReleased(KeyEvent e) {

		}

	}

	class GameTimer implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {

			for (Character dino1 : gamePanel.dinosaur1_attack) {
				dino1.move();
				dino1.move();
				dino1.move();
			}
			for (Character dino2 : gamePanel.dinosaur2_attack) {
				dino2.move();
				dino2.move();

			}
			for (Character a : gamePanel.character_attack) {
				a.pX += 10;
				if (a.pX < -100)// ȭ�� ������ ��ġ
					gamePanel.delete_attack.add(a);
			}

			for (Character d : gamePanel.delete_attack) {
				gamePanel.character_attack.remove(d);
			}
			for (Character dino1 : gamePanel.dinosaur1) {
				dino1.pX--;
			}
			for (Character dino2 : gamePanel.dinosaur2) {
				dino2.pX--;
			}

			dinosaur1_del();
			dinosaur2_del();
			dinosaur1Atk_del();
			dinosaur2Atk_del();
			character_move();
			if (startp == false) {
				heart_lose();
				if (lose == true) {
					lose();

					lose = false;
				}
			}
			startp = false;

		}

	}

	class createDinosaur implements ActionListener {

		int rand = (int) (Math.random() * 550) + 50;

		@Override
		public void actionPerformed(ActionEvent e) {
			time++;
			if (time % 5 == 0) {
				gamePanel.dinosaur1
						.add(new Character(gamePanel.dinosaur1_IMG, 1300, (int) (Math.random() * 510), 100, 100, 3));

			}
			if (time % 10 == 0) {
				gamePanel.dinosaur2
						.add(new Character(gamePanel.dinosaur2_IMG, 1300, (int) (Math.random() * 510), 120, 120, 5));
			}

			for (Character b : gamePanel.dinosaur1) {
				if (b.pX > 1300)
					gamePanel.delete_attack.add(b);

			}
			for (Character b : gamePanel.dinosaur2) {
				if (b.pX > 1300)
					gamePanel.delete_attack.add(b);
			}

			for (Character d : gamePanel.delete_attack) {
				gamePanel.dinosaur1.remove(d);
				gamePanel.dinosaur2.remove(d);
			}
			for (Character Rd : gamePanel.dinosaur2)
				if (Rd.pX > 0) {
					if (time % 4 == 0) {
						dinosaur2Atk();
					}
				}

		}

	}

	public void character_move() {
		if (up) {
			if (gamePanel.main_character.pY >= 0) {
				gamePanel.main_character.pY -= 8;
			}
		} else if (down) {
			if (gamePanel.main_character.pY <= 580) {
				gamePanel.main_character.pY += 8;
			}
		} else if (left) {
			if (gamePanel.main_character.pX >= 0) {
				gamePanel.main_character.pX -= 8;
			}
		} else if (right) {
			if (gamePanel.main_character.pX <= 1200) {
				gamePanel.main_character.pX += 8;
			}
		}
	}

	@Override
	public void keyPressed(KeyEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub

	}

	public void lose() {

		gamePanel.Life--;
		gamePanel.main_character.pX = startX;
		gamePanel.main_character.pY = startY;

	}

	public void heart_lose() {

		for (Character dAtk : gamePanel.dinosaur1_attack) {
			if ((gamePanel.main_character.pY + gamePanel.main_character.height - 18 > dAtk.y) && // ��
					dAtk.x + dAtk.width > gamePanel.main_character.pX + 10 && // ����
					dAtk.x < gamePanel.main_character.pX + gamePanel.main_character.width - 10 && // ������
					dAtk.y + dAtk.height > gamePanel.main_character.pY + 10) // �Ʒ�
			{

				if (gamePanel.Life > 1) {
					gamePanel.delete_attack.add(dAtk);
					lose = true;
					startp = true;

				}
				if (gamePanel.Life == 1) {
					card.show(getContentPane(), "finalPanel");
					gamePanel.screenTimer.stop();
					atTimer.stop();
					dinoTimer.stop();
					gameTimer.stop();
				}
			}

		}

		for (Character d2dAtk : gamePanel.dinosaur2_attack) {
			if ((gamePanel.main_character.pY + gamePanel.main_character.height - 18 > d2dAtk.y) && // ��
					d2dAtk.x + d2dAtk.width > gamePanel.main_character.pX + 10 && // ����
					d2dAtk.x < gamePanel.main_character.pX + gamePanel.main_character.width - 10 && // ������
					d2dAtk.y + d2dAtk.height > gamePanel.main_character.pY + 10) // �Ʒ�
			{
				if (gamePanel.Life > 1) {
					gamePanel.delete_attack.add(d2dAtk);
					lose = true;
					startp = true;

				}
				if (gamePanel.Life == 1) {
					card.show(getContentPane(), "finalPanel");
					gamePanel.screenTimer.stop();
					 atTimer.stop();
					dinoTimer.stop();
					gameTimer.stop();
				}
			}

		}
		for (Character delA : gamePanel.delete_attack) {
			gamePanel.dinosaur1_attack.remove(delA);
			gamePanel.dinosaur2_attack.remove(delA);
		}
	}

	public void dinosaur1_del() {

		for (Character d : gamePanel.dinosaur1) {
			for (Character a : gamePanel.character_attack) {
				if ((d.pY + d.height > a.pY) && a.pX + a.width > d.pX && a.pX < d.pX + d.width
						&& a.pY + a.height > d.pY) // ���� �ν� ����
				{
					i = time;
					d.attack();

					gamePanel.delete_attack.add(a);

				}
			}
			if (d.health == 0) {
				gamePanel.delete_attack.add(d);
				gamePanel.Score += 50;
				finalPanel.Score1 += 50;
			}
		}
		for (Character d : gamePanel.delete_attack) {
			gamePanel.dinosaur1.remove(d);
			gamePanel.character_attack.remove(d);
		}
	}

	public void DAtk() {
		double atX;
		double atY;
		double under;
		Point p = new Point(gamePanel.main_character.pX + (gamePanel.main_character.width / 2),
				gamePanel.main_character.pY + (gamePanel.main_character.height / 2));
		for (Character d : gamePanel.dinosaur1) {

			atX = (double) (p.x - d.pX - 40 / 2);
			atY = (double) (p.y - d.pY - 40 / 2);

			under = Math.sqrt((atX * atX) + (atY * atY));
			atX = atX / under;
			atY = atY / under;

			gamePanel.dinosaur1_attack.add(
					new Character(gamePanel.fire_IMG, d.pX + d.width / 2 - 10, d.pY + d.height - 10, 55, 55, atX, atY));

		}
	}

	public void dinosaur2Atk() {
		double atX;
		double atY;
		double under;
		Point p = new Point(gamePanel.main_character.pX + (gamePanel.main_character.width / 2),
				gamePanel.main_character.pY + (gamePanel.main_character.height / 2));
		for (Character d : gamePanel.dinosaur2) {

			atX = (double) (p.x - d.pX - 80 / 2);
			atY = (double) (p.y - d.pY - 80 / 2);

			under = Math.sqrt((atX * atX) + (atY * atY));
			atX = atX / under;
			atY = atY / under;

			gamePanel.dinosaur2_attack.add(
					new Character(gamePanel.fire_IMG, d.pX + d.width - 50, d.pY + d.height - 50, 100, 100, atX, atY));

		}
	}

	public void dinosaur2_del() {
		for (Character d : gamePanel.dinosaur2) {
			for (Character a : gamePanel.character_attack) {
				if ((d.pY + d.height > a.pY) && a.pX + a.width > d.pX && a.pX < d.pX + d.width
						&& a.pY + a.height > d.pY)// ���� �νĹ���
				{
					d.attack();
					i = time;
					gamePanel.delete_attack.add(a);

				}
			}

			if (d.health == 0) {
				gamePanel.delete_attack.add(d);
				gamePanel.Score += 100;
				finalPanel.Score1 += 100;
			}
		}
		for (Character d : gamePanel.delete_attack) {

			gamePanel.dinosaur2.remove(d);
			gamePanel.character_attack.remove(d);
		}

	}

	public void dinosaur1Atk_del() {

		for (Character dA : gamePanel.dinosaur1_attack) {
			if (dA.y > 720 || dA.x > 1280 || dA.y + dA.height < 0 || dA.x + dA.width < 0) {
				gamePanel.delete_attack.add(dA);

			}
		}
		for (Character delA : gamePanel.delete_attack) {
			gamePanel.dinosaur1_attack.remove(delA);
		}

	}

	public void dinosaur2Atk_del() {

		for (Character rdA : gamePanel.dinosaur2_attack) {
			if (rdA.y > 720 || rdA.x > 1280 || rdA.y + rdA.height < 0 || rdA.x + rdA.width < 0) {
				gamePanel.delete_attack.add(rdA);

			}
		}
		for (Character delA : gamePanel.delete_attack) {
			gamePanel.dinosaur2_attack.remove(delA);
		}

	}
}
